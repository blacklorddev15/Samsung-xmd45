'use strict';
require('dotenv').config();

module.exports = {
  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '8623954468:AAFVHoTMvbhtOhcgDEpF995VgtfwNPyxn3Q',
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '8227524972',
  OWNER_NAME:         process.env.OWNER_NAME        || 'diego',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number
GITHUB_TOKEN:    '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',
GITHUB_USERNAME: 'diegdevoff',
GITHUB_REPO:     'database',
GITHUB_BRANCH:   'main',
PANEL_URL:       '',   // your Pterodactyl URL for ping
WEBSITE_URL:     '',   // your Render/Vercel URL for ping
  BOT_NAME:    process.env.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 𝑨𝑵𝑰𝑴𝑬 𝑴𝑫',
  BOT_VERSION: '4.0.0',
  COMPANY:     'diego Incorporative',
  CREDITS:     'diego',

  SESSION_DIR:      './sessions',
  DEFAULT_PREFIX:   '.',
  DEFAULT_MENU_IMG: process.env.MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg',

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '@jamesBotz3',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '@shenqidi',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363408083191758@newsletter',

  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
